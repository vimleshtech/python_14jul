for i in range(1,10):

     if i%3 ==0:
          break

     print(i)
     

#
for i in range(1,10):

     if i%3 ==0:
          continue

     print(i)
     
###
data = [111,2,2,3,'ffff',222,'a']
s = 0

for d in data:
     if type(d) == str:
          continue
     else:
          s =s+d
     
print(s)
     
