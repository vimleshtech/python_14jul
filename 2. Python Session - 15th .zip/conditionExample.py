## wap to get number from user and show greater no.

n1 = int(input('enter no. :'))
n2 = int(input('enter no. :'))

if n1>n2:
     print('n1 is greater')
else:
     print('n2 is greater')


##wap to take three numebr from user and show greater no.
     
n1 = int(input('enter no. :'))
n2 = int(input('enter no. :'))
n3 = int(input('enter no. :'))

if n1>n2 and n1>n3:
     print('n1 is greater')
elif n2>n1 and n2>n3:
     print('n2 is greater')
else:
     print('n3 is greater')
     

#wap to calucate amount for elec. unit
mrent  = 50
unit = int(input('enter unit :' ))
pr = 0
if unit<100:
     pr = unit*.40
elif unit<300:
     pr = 40+ (unit-100)*.50
     
else:
     pr = 140+ (unit-300)*.60
total_price = mrent+pr
print('total bill amount :',total_price)








     
     





     









     
