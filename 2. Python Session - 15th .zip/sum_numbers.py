
for i in range(1,10):
     print(i,end=' ')
     
n = int(input("Enter Number ::"))

se=0
so=0
s=0
i=0
co=0
ce=0

for i in range(1,n):
     if(i%2==0):
               se=se+i
               ce=ce+1
     else:
               so=so+i
               co=co+1  

"""
while i<=n:
     s=s+i
     i=i+1"""

print("Sum even:",se,"Average is:",(se/ce))
print("Sum odd:",so,"Average is:",(so/co))

