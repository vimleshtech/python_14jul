for d in range(1,10): #from 1 to 9, default incrementer is 1
     print(d)
     
#print odd numbers
for d in range(1,10,2): #from 1 to 9
     print(d)

#print in reverse
for a in range(10,0,-1):#from 10 to 1
     print(a)
     


