"""n=int(input("Enter Number::"))

t=1

for i in range(1,11):
     
     print(n,"*",i,"=",n*i)
   """

n=int(input ("print no of series:"))
i=1
t=2
for i in range(1,n):
     if(i%2==0):
          t=t*2
          print(t)
          continue
     
     
     

      
